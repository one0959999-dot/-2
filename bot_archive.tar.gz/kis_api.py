import requests
import json
import pandas as pd

class KisApi:
    """한국투자증권 OpenAPI 연동을 위한 클래스입니다."""
    
    def __init__(self, app_key: str, app_secret: str, account_no: str, is_mock: bool = True):
        self.app_key = app_key
        self.app_secret = app_secret
        self.account_no = account_no
        self.is_mock = is_mock
        
        # 모의투자 및 실전투자 URL 구분
        self.base_url = "https://openapivts.koreainvestment.com:29443" if is_mock else "https://openapi.koreainvestment.com:9443"
        self.access_token = None
        
    def get_access_token(self):
        """API 사용을 위한 토큰 발급"""
        print("[KIS] 접속 토큰(Access Token) 발급을 요청합니다...")
        url = f"{self.base_url}/oauth2/tokenP"
        headers = {"content-type": "application/json"}
        body = {
            "grant_type": "client_credentials",
            "appkey": self.app_key,
            "appsecret": self.app_secret
        }
        res = requests.post(url, headers=headers, data=json.dumps(body))
        
        if res.status_code == 200:
            self.access_token = res.json().get('access_token')
            print("[KIS] 토큰 발급 완료!")
            return self.access_token
        else:
            print(f"[KIS] 토큰 발급 실패: {res.text}")
            return None

    def _ensure_token(self):
        """토큰이 없으면 자동 발급"""
        if not self.access_token:
            return self.get_access_token()
        return self.access_token

    def _order_headers(self, tr_id: str) -> dict:
        """주문 공통 헤더 생성"""
        return {
            "content-type": "application/json; charset=utf-8",
            "authorization": f"Bearer {self.access_token}",
            "appkey": self.app_key,
            "appsecret": self.app_secret,
            "tr_id": tr_id,
        }
        
    def get_current_price(self, stock_code: str):
        """특정 종목의 현재가 조회"""
        if not self._ensure_token():
            print("[KIS] 접속 토큰이 없어 현재가를 조회할 수 없습니다. (APP_KEY 등을 확인해주세요)")
            return None
            
        url = f"{self.base_url}/uapi/domestic-stock/v1/quotations/inquire-price"
        headers = {
            "content-type": "application/json; charset=utf-8",
            "authorization": f"Bearer {self.access_token}",
            "appkey": self.app_key,
            "appsecret": self.app_secret,
            "tr_id": "FHKST01010100"
        }
        params = {
            "fid_cond_mrkt_div_code": "J",
            "fid_input_iscd": stock_code
        }
        res = requests.get(url, headers=headers, params=params)
        
        if res.status_code == 200:
            data = res.json()
            if data['rt_cd'] == '0':
                price = int(data['output']['stck_prpr'])
                return price
            else:
                print(f"[KIS] 현재가 조회 오류: {data['msg1']}")
                return None
        else:
            print(f"[KIS] 현재가 조회 통신 실패: {res.text}")
            return None

    def _place_order(self, stock_code: str, qty: int, side: str):
        """
        시장가 주문 공통 로직
        side: 'BUY' | 'SELL'
        """
        if not self._ensure_token():
            return None

        # 실전: TTTC0802U(매수) / TTTC0801U(매도)
        # 모의: VTTC0802U(매수) / VTTC0801U(매도)
        if side == 'BUY':
            tr_id = "VTTC0802U" if self.is_mock else "TTTC0802U"
        else:
            tr_id = "VTTC0801U" if self.is_mock else "TTTC0801U"

        # 계좌번호 분리 (앞 8자리 + 뒤 2자리)
        acnt_no   = self.account_no[:8]
        acnt_prdt = self.account_no[8:] if len(self.account_no) > 8 else "01"

        url  = f"{self.base_url}/uapi/domestic-stock/v1/trading/order-cash"
        body = {
            "CANO":           acnt_no,
            "ACNT_PRDT_CD":   acnt_prdt,
            "PDNO":           stock_code,
            "ORD_DVSN":       "01",   # 01 = 시장가
            "ORD_QTY":        str(qty),
            "ORD_UNPR":       "0",    # 시장가는 0
        }

        res = requests.post(
            url,
            headers=self._order_headers(tr_id),
            data=json.dumps(body)
        )

        if res.status_code == 200:
            data = res.json()
            if data.get('rt_cd') == '0':
                odno = data['output'].get('ODNO', '-')
                label = '매수' if side == 'BUY' else '매도'
                print(f"[KIS] {label} 주문 완료 | {stock_code} {qty}주 | 주문번호: {odno}")
                return data
            else:
                msg_cd = data.get('msg_cd', '')
                print(f"[KIS] 주문 실패: {data.get('msg1', res.text)}")
                # 토큰 만료(EGW00123/EGW00121) → 재발급 후 1회 재시도
                if msg_cd in ('EGW00123', 'EGW00121'):
                    print("[KIS] 토큰 만료 → 재발급 후 재시도")
                    self.access_token = None
                    self._ensure_token()
                    return self._place_order(stock_code, qty, side)
                return None
        else:
            print(f"[KIS] 주문 통신 오류: {res.status_code} {res.text}")
            return None
        
    def buy_market_order(self, stock_code: str, qty: int):
        """시장가 매수 주문"""
        if qty <= 0:
            return None
        return self._place_order(stock_code, qty, 'BUY')
        
    def sell_market_order(self, stock_code: str, qty: int):
        """시장가 매도 주문"""
        if qty <= 0:
            return None
        return self._place_order(stock_code, qty, 'SELL')

if __name__ == '__main__':
    # 테스트 코드
    pass
