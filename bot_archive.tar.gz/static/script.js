document.addEventListener('DOMContentLoaded', () => {

    // ── DOM refs ──
    const btnToggle    = document.getElementById('btn-toggle');
    const toggleLabel  = document.getElementById('toggle-label');
    const miniLog      = document.getElementById('mini-log');
    const satTbody     = document.getElementById('sat-tbody');

    // ── P&L Chart 초기화 ──
    let pnlChart = null;

    function initChart(labels, values) {
        const ctx = document.getElementById('pnl-chart').getContext('2d');
        const empty = document.getElementById('chart-empty');

        if (!labels || labels.length === 0) {
            empty.style.display = 'flex';
            return;
        }
        empty.style.display = 'none';

        const colors = values.map(v =>
            v >= 0 ? 'rgba(63,185,80,0.75)' : 'rgba(248,81,73,0.75)'
        );
        const borderColors = values.map(v =>
            v >= 0 ? 'rgba(63,185,80,1)' : 'rgba(248,81,73,1)'
        );

        if (pnlChart) {
            pnlChart.data.labels = labels;
            pnlChart.data.datasets[0].data   = values;
            pnlChart.data.datasets[0].backgroundColor  = colors;
            pnlChart.data.datasets[0].borderColor = borderColors;
            pnlChart.update('none');
            return;
        }

        pnlChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels,
                datasets: [{
                    label: '일별 손익 (원)',
                    data:   values,
                    backgroundColor:  colors,
                    borderColor:      borderColors,
                    borderWidth:      1.5,
                    borderRadius:     6,
                    borderSkipped:    false,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: ctx => {
                                const v = ctx.parsed.y;
                                return ` ${v >= 0 ? '+' : ''}${v.toLocaleString()}원`;
                            }
                        },
                        backgroundColor: 'rgba(22,27,34,0.95)',
                        titleColor: '#8b949e',
                        bodyColor:  '#e6edf3',
                        borderColor:'rgba(255,255,255,0.1)',
                        borderWidth: 1,
                        padding: 10,
                    }
                },
                scales: {
                    x: {
                        grid:  { color: 'rgba(255,255,255,0.05)' },
                        ticks: { color: '#8b949e', font: { size: 11 } }
                    },
                    y: {
                        grid:  { color: 'rgba(255,255,255,0.05)' },
                        ticks: {
                            color: '#8b949e',
                            font:  { size: 11 },
                            callback: v => (v >= 0 ? '+' : '') + v.toLocaleString() + '원'
                        }
                    }
                }
            }
        });
    }

    // ── Toggle Button ──
    btnToggle.addEventListener('click', () => {
        fetch('/api/toggle', { method: 'POST' })
            .then(r => r.json())
            .then(() => fetchStatus());
    });

    // ── Status Fetch ──
    function fetchStatus() {
        fetch('/api/status')
            .then(r => r.json())
            .then(data => updateUI(data))
            .catch(e => console.error('status fetch error', e));
    }

    function fetchPnl() {
        fetch('/api/pnl')
            .then(r => r.json())
            .then(data => {
                initChart(data.labels, data.values);

                const todayStr = new Date().toISOString().slice(0, 10);
                const monthStr = new Date().toISOString().slice(0, 7);
                const yearStr  = new Date().toISOString().slice(0, 4);

                let total = 0, monthly = 0, yearly = 0;

                (data.values || []).forEach((val, i) => {
                    total += val;
                    const dateStr = data.labels[i];
                    if (dateStr.startsWith(monthStr)) monthly += val;
                    if (dateStr.startsWith(yearStr))  yearly += val;
                });

                const formatPnl = (val) => (val >= 0 ? '+' : '') + val.toLocaleString() + '원';
                const colorPnl  = (val) => val >= 0 ? '#3fb950' : '#f85149';

                const elMonth = document.getElementById('chart-monthly-pnl');
                const elYear  = document.getElementById('chart-yearly-pnl');
                const elTotal = document.getElementById('chart-total-pnl');

                if (elMonth) { elMonth.textContent = `이번달: ${formatPnl(monthly)}`; elMonth.style.color = colorPnl(monthly); }
                if (elYear)  { elYear.textContent  = `올해: ${formatPnl(yearly)}`; elYear.style.color = colorPnl(yearly); }
                if (elTotal) { elTotal.textContent = `누적: ${formatPnl(total)}`; elTotal.style.color = colorPnl(total); }
            });
    }

    // ── Main UI Update ──
    function updateUI(data) {

        // Toggle button state
        const running = data.is_running;
        if (running) {
            btnToggle.className = 'btn-toggle btn-running';
            toggleLabel.textContent = '⏹ Running';
        } else {
            btnToggle.className = 'btn-toggle btn-stopped';
            toggleLabel.textContent = 'Stopped';
        }

        // Hot Sectors Badge
        const hotSectorsEl = document.getElementById('hot-sectors');
        if (data.hot_sectors && data.hot_sectors.length > 0) {
            hotSectorsEl.textContent = '🔥 현재 강세 섹터: ' + data.hot_sectors.join(', ');
        } else {
            hotSectorsEl.textContent = '🔥 분석 중이거나 강세 섹터가 없습니다.';
        }

        // ── Portfolio Cards ──
        const cores = data.cores || [];
        const sats = data.satellites || [];
        
        if (data.num_satellites !== undefined) {
            document.getElementById('sat-num-display').textContent = data.num_satellites;
        }

        // Dynamic Core cards
        // 먼저 기존 코어 카드들을 지웁니다 (클래스가 info-card core-card 인 것들)
        document.querySelectorAll('.core-card').forEach(e => e.remove());
        
        let totalCoreValue = 0;
        const topCardsContainer = document.getElementById('top-cards-container');
        const satCard = topCardsContainer.lastElementChild; // 위성 합계 카드

        cores.forEach((core) => {
            totalCoreValue += (core.value || 0);
            const div = document.createElement('div');
            div.className = 'info-card glass-card core-card';
            div.innerHTML = `
                <h3>💎 ${core.name} (Core)</h3>
                <div class="card-value highlight">${(core.shares || 0).toLocaleString()} 주</div>
                <div class="card-subvalue">평가금액 ${(core.value || 0).toLocaleString()}원</div>
                <div class="card-subvalue" style="color:#f59e0b;font-size:0.8rem;margin-top:4px">🔒 floor: ${core.floor}주 영구 보호</div>
            `;
            topCardsContainer.insertBefore(div, satCard);
        });

        // Satellite total
        const satTotal = sats.reduce((s, p) => s + (p.value || 0), 0);
        document.getElementById('sat-total-value').textContent =
            satTotal.toLocaleString() + '원';
        document.getElementById('sat-count').textContent =
            `종목 수: ${sats.length}개`;

        // Total portfolio value
        const totalVal = totalCoreValue + satTotal;
        document.getElementById('total-value').textContent =
            totalVal > 0 ? totalVal.toLocaleString() + '원' : '-';

        // ── Satellite Table ──
        if (sats.length > 0) {
            satTbody.innerHTML = '';
            sats.forEach(s => {
                const statusBadge = s.shares > 0
                    ? `<span class="badge badge-holding">보유 ${s.shares.toLocaleString()}주</span>`
                    : `<span class="badge badge-hold">대기중</span>`;
                const stratBadge = s.strategy
                    ? `<span class="badge badge-strategy">${s.strategy}</span>`
                    : '<span style="color:#8b949e">-</span>';
                satTbody.innerHTML += `
                    <tr>
                        <td><b>${s.name}</b>
                            <span style="color:#64748b;font-size:0.78rem;margin-left:5px">${s.ticker}</span>
                        </td>
                        <td>${stratBadge}</td>
                        <td>${s.shares > 0 ? s.shares.toLocaleString() + '주' : '-'}</td>
                        <td>${(s.value || 0).toLocaleString()}원</td>
                        <td>${statusBadge}</td>
                    </tr>`;
            });
        }

        // ── Mini Log (Header) ──
        if (data.logs && data.logs.length > 0) {
            const recent = data.logs.slice(-6);
            miniLog.innerHTML = '';
            recent.forEach(log => {
                const div = document.createElement('div');
                div.className = 'mini-log-entry';
                div.innerHTML =
                    `<span class="log-time">[${log.time}]</span>${log.message}`;
                miniLog.appendChild(div);
            });
            miniLog.scrollTop = miniLog.scrollHeight;
        }
    }

    // ── Polling ──
    fetchStatus();
    fetchPnl();
    setInterval(fetchStatus, 3000);
    setInterval(fetchPnl,    10000);   // 차트는 10초마다 갱신

    // Global func for adjusting sat count
    window.adjustSat = function(delta) {
        const el = document.getElementById('sat-num-display');
        let val = parseInt(el.textContent) + delta;
        if (val < 1) val = 1;
        if (val > 15) val = 15;
        el.textContent = val;
        
        fetch('/api/settings/satellites', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ count: val })
        }).then(r => r.json()).then(res => {
            if (res.status === 'success') {
                console.log('Satellite count updated to ' + res.num_satellites);
            }
        });
    }

});
