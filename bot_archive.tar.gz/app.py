from flask import Flask, render_template, jsonify
from bot_controller import BotController

app = Flask(__name__)
bot = BotController()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/status')
def status():
    return jsonify(bot.get_status())

@app.route('/api/toggle', methods=['POST'])
def toggle_bot():
    if bot.is_running:
        bot.stop()
        return jsonify({"status": "stopped"})
    else:
        bot.start()
        return jsonify({"status": "started"})

@app.route('/api/start', methods=['POST'])
def start_bot():
    bot.start()
    return jsonify(bot.get_status())

@app.route('/api/stop', methods=['POST'])
def stop_bot():
    bot.stop()
    return jsonify(bot.get_status())

@app.route('/api/pnl')
def pnl():
    return jsonify(bot.get_pnl_data())

from flask import request
@app.route('/api/settings/satellites', methods=['POST'])
def set_satellites():
    data = request.json
    count = data.get('count', 5)
    if 1 <= count <= 15:
        bot.num_satellites = count
        return jsonify({"status": "success", "num_satellites": bot.num_satellites})
    return jsonify({"status": "error", "message": "Invalid count"}), 400

if __name__ == '__main__':
    # 외부 기기 접속을 허용하기 위해 host를 '0.0.0.0'으로 설정합니다.
    app.run(host='0.0.0.0', port=5000, debug=False)
