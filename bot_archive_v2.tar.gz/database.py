import sqlite3
import os
from werkzeug.security import generate_password_hash, check_password_hash

DB_PATH = 'users.db'

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 사용자 테이블
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        kis_app_key TEXT,
        kis_app_secret TEXT,
        kis_account_no TEXT,
        telegram_token TEXT,
        telegram_chat_id TEXT,
        initial_cash REAL DEFAULT 10000000
    )
    ''')
    
    # 봇 상태 테이블 (간이 저장용 - JSON 형태로 저장 예정)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS bot_states (
        user_id INTEGER PRIMARY KEY,
        state_json TEXT,
        last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    ''')
    
    conn.commit()
    conn.close()

def add_user(username, password):
    conn = get_db_connection()
    cursor = conn.cursor()
    password_hash = generate_password_hash(password)
    try:
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, password_hash))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()

def verify_user(username, password):
    conn = get_db_connection()
    cursor = conn.cursor()
    user = cursor.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    conn.close()
    
    if user and check_password_hash(user['password_hash'], password):
        return dict(user)
    return None

def update_user_keys(user_id, keys_dict):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute('''
        UPDATE users 
        SET kis_app_key = ?, kis_app_secret = ?, kis_account_no = ?, 
            telegram_token = ?, telegram_chat_id = ?
        WHERE id = ?
    ''', (
        keys_dict.get('kis_app_key'),
        keys_dict.get('kis_app_secret'),
        keys_dict.get('kis_account_no'),
        keys_dict.get('telegram_token'),
        keys_dict.get('telegram_chat_id'),
        user_id
    ))
    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_db()
    print("Database initialized.")
