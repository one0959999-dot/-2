from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from bot_controller import manager
from database import get_db_connection, verify_user, add_user, init_db, update_user_keys
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Flask-Login 설정
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User(UserMixin):
    def __init__(self, id, username, data):
        self.id = id
        self.username = username
        self.data = data

@login_manager.user_loader
def load_user(user_id):
    conn = get_db_connection()
    user_data = conn.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
    conn.close()
    if user_data:
        return User(user_data['id'], user_data['username'], dict(user_data))
    return None

# --- 웹 페이지 경로 ---

@app.route('/')
@login_required
def index():
    return render_template('index.html', user=current_user)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        user_data = verify_user(username, password)
        if user_data:
            user = User(user_data['id'], user_data['username'], user_data)
            login_user(user)
            return redirect(url_for('index'))
        flash('아이디 또는 비밀번호가 올바르지 않습니다.')
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if add_user(username, password):
            flash('회원가입이 완료되었습니다. 로그인해 주세요.')
            return redirect(url_for('login'))
        flash('이미 존재하는 아이디입니다.')
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# --- API 경로 (로그인 필요) ---

def get_current_bot():
    return manager.get_bot(current_user.id, current_user.data)

@app.route('/api/status')
@login_required
def status():
    bot = get_current_bot()
    return jsonify(bot.get_status())

@app.route('/api/toggle', methods=['POST'])
@login_required
def toggle_bot():
    bot = get_current_bot()
    if bot.is_running:
        bot.stop()
        return jsonify({"status": "stopped"})
    else:
        bot.start()
        return jsonify({"status": "started"})

@app.route('/api/pnl')
@login_required
def pnl():
    bot = get_current_bot()
    return jsonify(bot.get_pnl_data())

@app.route('/api/settings/satellites', methods=['POST'])
@login_required
def set_satellites():
    bot = get_current_bot()
    data = request.json
    count = data.get('count', 5)
    if 1 <= count <= 15:
        bot.num_satellites = count
        return jsonify({"status": "success", "num_satellites": bot.num_satellites})
    return jsonify({"status": "error", "message": "Invalid count"}), 400

@app.route('/api/settings/keys', methods=['POST'])
@login_required
def set_keys():
    data = request.json
    update_user_keys(current_user.id, data)
    # 봇 인스턴스 정보 갱신 (다음 get_bot 호출 시 반영되게 하거나 현재 인스턴스 업데이트)
    if current_user.id in manager.bots:
        del manager.bots[current_user.id] # 재설정을 위해 인스턴스 삭제
    return jsonify({"status": "success"})

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=False)
