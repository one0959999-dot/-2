"""
bot_controller.py
코어-위성 전략 자동 매매 봇 컨트롤러
- 시작 시 위성 종목 자동 스크리닝 (KOSPI 상위 50 종목)
- 종목마다 13가지 전략 백테스트 후 최고 수익 전략 개별 적용
- 보령: RSI(9) + floor 보호 / 위성: 종목별 최적 전략
- 수익 발생 시 수익금 50% 보령 자동 재투자
- 매월 1회 위성 종목 & 전략 재선정
"""

import threading
import time
import schedule
from datetime import datetime

from kis_api import KisApi
from telegram_bot import TelegramNotifier
from strategy import CorePosition, Position, get_rsi_signal, get_signal_by_strategy, REINVEST_RATIO
from stock_screener import select_satellites
from main import load_config

CORE_TICKER    = "003850"
CORE_NAME      = "보령"
CORE_RATIO     = 0.30
SATELLITE_RATIO = 0.70

class BotController:
    def __init__(self, user_id, kis_config=None, telegram_config=None):
        self.user_id      = user_id
        self.is_running   = False
        self.thread       = None
        self.logs         = []
        self.num_satellites = 5

        # 포지션
        self.core_positions      = []   # list of CorePosition
        self.satellite_positions = {}   # {ticker: Position}
        self.satellite_info      = []   # [{'ticker','name','strategy_name','return_pct'}]
        self.satellite_strategies = {}  # {ticker: strategy_name}

        # 일별 수익 추적 {date_str: profit}
        self.daily_pnl = {}

        # 월별 재선정 카운터
        self.last_screen_month = None

        # 현재 강세 섹터 (대시보드 표시용)
        self.hot_sectors = []

        # API 연동 객체
        self.kis = None
        self.telegram = None

        if kis_config and kis_config.get('app_key'):
            self.kis = KisApi(
                app_key=kis_config.get('app_key', '').strip(),
                app_secret=kis_config.get('app_secret', '').strip(),
                account_no=kis_config.get('account_no', '').strip(),
                is_mock=kis_config.get('is_mock', True)
            )
        
        if telegram_config and telegram_config.get('token'):
            self.telegram = TelegramNotifier(
                token=telegram_config.get('token', '').strip(),
                chat_id=telegram_config.get('chat_id', '').strip()
            )
        self.add_log(f"User {user_id} Bot Controller 초기화 완료.")

    # ─── 로그 ───
    def add_log(self, msg):
        t = datetime.now().strftime("%H:%M:%S")
        entry = {"time": t, "message": msg}
        self.logs.append(entry)
        print(f"[{t}] {msg}")
        if len(self.logs) > 100:
            self.logs.pop(0)

    # ─── 초기화 ───
    def initialize_portfolio(self, total_cash):
        """포트폴리오 초기 구성"""
        self.add_log("포트폴리오 초기화 중...")

        # 1. 위성 종목 & 전략 스크리닝
        self.add_log("📡 위성 종목 & 최적 전략 자동 스크리닝 중... (1~2분 소요)")
        self.satellite_info, self.hot_sectors = select_satellites(n=self.num_satellites, verbose=False)
        
        from stock_screener import select_ai_core_stock
        ai_core_info = select_ai_core_stock(verbose=False)

        # 결과 로그
        self.satellite_strategies = {c['ticker']: c['strategy_name'] for c in self.satellite_info}
        log_lines = []
        for i, c in enumerate(self.satellite_info):
            line = f"  {i+1}. {c['name']} ({c['ticker']}) → [{c['strategy_name']}] {c['return_pct']:+.1f}%"
            log_lines.append(line)
            self.add_log(f"✅ {line.strip()}")
        if self.telegram:
            self.telegram.send_message("🔍 위성 종목 & 전략 선정!\n" + "\n".join(log_lines))

        # 2. 자금 배분
        core_budget = total_cash * CORE_RATIO
        sat_budget  = total_cash * SATELLITE_RATIO
        per_sat     = sat_budget / self.num_satellites if self.num_satellites > 0 else 0

        # 3. 코어 포지션 초기화 (듀얼 코어)
        self.core_positions = []
        
        # 3-1. 첫번째 코어: 보령
        half_core_budget = core_budget / 2
        boryung_core = CorePosition(CORE_TICKER, CORE_NAME, initial_cash=half_core_budget)
        bp = self.kis.get_current_price(CORE_TICKER) if self.kis else 9000
        if bp:
            qty = boryung_core.buy(bp)
            self.add_log(f"💎 보령 초기 매수: {bp:,}원 × {qty}주 = {qty*bp:,}원 | floor: {boryung_core.floor_shares}주 보호")
        self.core_positions.append(boryung_core)
        
        # 3-2. 두번째 코어: AI 장기 우상향
        if ai_core_info:
            ai_core = CorePosition(ai_core_info['ticker'], ai_core_info['name'], initial_cash=half_core_budget)
            ap = self.kis.get_current_price(ai_core_info['ticker']) if self.kis else 50000
            if ap:
                qty = ai_core.buy(ap)
                self.add_log(f"💎 AI 코어({ai_core_info['name']}) 매수: {ap:,}원 × {qty}주 = {qty*ap:,}원 | floor: {ai_core.floor_shares}주 보호")
            self.core_positions.append(ai_core)

        # 5. 위성 포지션 초기화
        self.satellite_positions = {}
        for c in self.satellite_info:
            self.satellite_positions[c['ticker']] = Position(c['ticker'], c['name'], per_sat)
        self.add_log(f"위성 자금 배분: 종목당 {per_sat:,.0f}원")
        self.last_screen_month = datetime.now().month

    # ─── 트레이딩 잡 ───
    def trading_job(self):
        if not self.core_positions:
            self.add_log("⚠️ 포트폴리오가 초기화되지 않았습니다.")
            return

        now = datetime.now()
        self.add_log(f"--- 매매 신호 점검 ({now.strftime('%H:%M')}) ---")

        # ── 코어 현재가 및 신호 점검 ──
        for core in self.core_positions:
            cp = self.kis.get_current_price(core.ticker) if self.kis else None
            if not cp: continue
            
            core_val = core.shares * cp
            self.add_log(
                f"💎 {core.name} 현황: {core.shares}주 "
                f"(floor: {core.floor_shares}주) "
                f"× {cp:,}원 = {core_val:,}원"
            )

            # 코어 매매 로직 (RSI)
            try:
                core_signal, _, core_rsi = get_rsi_signal(core.ticker)

                if core_signal == 'BUY' and core.cash >= (cp or 1):
                    qty = core.buy(cp)
                    if qty > 0:
                        if self.kis:
                            self.kis.buy_market_order(core.ticker, qty)
                        msg = f"💎 {core.name} 매수 {qty}주 @ {cp:,}원 (RSI:{core_rsi:.1f}) → 총 {core.shares}주"
                        self.add_log(msg)
                        if self.telegram:
                            self.telegram.send_message(msg)

                elif core_signal == 'SELL' and core.shares > core.floor_shares:
                    if self.kis:
                        sellable = core.shares - core.floor_shares
                        self.kis.sell_market_order(core.ticker, sellable)
                    qty, profit = core.sell(cp)
                    if qty > 0:
                        msg = f"💎 {core.name} 익절 매도 {qty}주 @ {cp:,}원 (RSI:{core_rsi:.1f}) | 이익 {profit:,.0f}원"
                        self.add_log(msg)
                        self.daily_pnl[now.strftime('%Y-%m-%d')] = self.daily_pnl.get(now.strftime('%Y-%m-%d'), 0) + profit
                        if self.telegram:
                            self.telegram.send_message(msg)
                else:
                    self.add_log(f"  [{core.name}] HOLD (RSI:{core_rsi:.1f}, floor:{core.floor_shares}주 보호)")
            except Exception as e:
                self.add_log(f"  [{core.name}] 점검 중 오류: {str(e)}")


        # ── 위성 신호 점검 (종목별 최적 전략 적용) ──
        for ticker, pos in self.satellite_positions.items():
            try:
                strat_name = self.satellite_strategies.get(ticker, 'RSI(9) 30/70')
                signal, price, ind_val = get_signal_by_strategy(ticker, strat_name)

                if signal == 'BUY' and pos.shares == 0:
                    if self.kis:
                        qty = int(pos.cash // price)
                        if qty > 0:
                            self.kis.buy_market_order(ticker, qty)
                    qty = pos.buy(price)
                    if qty > 0:
                        msg = f"📈 [{pos.name}] 매수 {qty}주 @ {price:,}원 [{strat_name} → {ind_val:.1f}]"
                        self.add_log(msg)
                        if self.telegram:
                            self.telegram.send_message(msg)

                elif signal == 'SELL' and pos.shares > 0:
                    if self.kis:
                        self.kis.sell_market_order(ticker, pos.shares)
                    qty, profit = pos.sell(price)
                    msg = (f"📉 [{pos.name}] 매도 {qty}주 @ {price:,}원 "
                           f"| 손익: {profit:+,.0f}원 [{strat_name} → {ind_val:.1f}]")
                    self.add_log(msg)
                    if self.telegram:
                        self.telegram.send_message(msg)

                    # 일별 수익 기록
                    today = datetime.now().strftime('%Y-%m-%d')
                    self.daily_pnl[today] = self.daily_pnl.get(today, 0) + profit

                    # 수익 발생 시 코어 재투자 (멀티 코어 균등 분배)
                    if profit > 0 and self.core_positions:
                        reinvest = profit * REINVEST_RATIO
                        if pos.cash >= reinvest:
                            pos.cash -= reinvest
                            split_amount = reinvest / len(self.core_positions)
                            
                            for core in self.core_positions:
                                core.cash += split_amount
                                
                            msg_dist = f"🔄 위성 수익 {profit:,.0f}원 중 {reinvest:,.0f}원을 코어({len(self.core_positions)}개) 매수자금으로 균등 편입"
                            self.add_log(msg_dist)
                            if self.telegram:
                                self.telegram.send_message(msg_dist)
                else:
                    self.add_log(f"  [{pos.name}] HOLD [{strat_name} → {ind_val:.1f}]")


            except Exception as e:
                self.add_log(f"⚠️ [{ticker}] 오류: {e}")

        # 매월 1회 위성 종목 재선정
        if now.month != self.last_screen_month:
            self.add_log("📅 월별 위성 종목 재선정 실행...")
            self._rescreen_satellites()
            self.last_screen_month = now.month

    def _rescreen_satellites(self):
        """위성 종목 & 전략 재선정 (매월 1회)"""
        new_info, self.hot_sectors = select_satellites(n=NUM_SATELLITES, verbose=False)
        new_tickers = {c['ticker'] for c in new_info}
        old_tickers = set(self.satellite_positions.keys())

        removed = old_tickers - new_tickers
        added   = new_tickers - old_tickers

        # 제거된 종목: 보유 주식 매도 후 자금 회수
        for ticker in removed:
            pos = self.satellite_positions[ticker]
            if pos.shares > 0:
                price = self.kis.get_current_price(ticker) if self.kis else 0
                if price:
                    self.kis.sell_market_order(ticker, pos.shares)
                    pos.sell(price)
            del self.satellite_positions[ticker]
            if ticker in self.satellite_strategies:
                del self.satellite_strategies[ticker]
            self.add_log(f"🔄 위성 제거: {pos.name}")

        for c in new_info:
            if c['ticker'] in added:
                budget = (SATELLITE_RATIO * sum(
                    p.current_value for p in self.satellite_positions.values()
                )) / self.num_satellites if self.satellite_positions else 0
                self.satellite_positions[c['ticker']] = Position(c['ticker'], c['name'], budget)
                self.satellite_strategies[c['ticker']] = c['strategy_name']
                self.add_log(f"🔄 위성 추가: {c['name']} → [{c['strategy_name']}] {c['return_pct']:+.1f}%")
            else:
                # 기존 종목도 전략 업데이트
                self.satellite_strategies[c['ticker']] = c['strategy_name']

        self.satellite_info = new_info
        lines = [f"  {c['name']} → [{c['strategy_name']}]" for c in new_info]
        msg = "📅 위성 재선정 완료!\n" + "\n".join(lines)
        if self.telegram:
            self.telegram.send_message(msg)

    # ─── 봇 시작/정지 ───
    def _run_loop(self, total_cash=10_000_000):
        self.initialize_portfolio(total_cash)
        schedule.clear()
        # 장중 매 5분마다 신호 점검 (실제 운용 시에는 더 길게)
        schedule.every(5).minutes.do(self.trading_job)
        self.trading_job()  # 즉시 1회 실행

        while self.is_running:
            schedule.run_pending()
            time.sleep(1)

    def start(self, total_cash=10_000_000):
        if not self.kis:
            self.add_log("❌ API 키가 설정되지 않았습니다. [계좌 설정]에서 먼저 키를 입력해주세요.")
            return False

        if not self.is_running:
            self.is_running = True
            self.thread = threading.Thread(
                target=self._run_loop,
                args=(total_cash,),
                daemon=True
            )
            self.thread.start()
            return True
        return False

    def stop(self):
        if self.is_running:
            self.is_running = False
            if self.thread:
                self.thread.join(timeout=3)
            self.add_log("봇이 정지되었습니다.")

    # ─── 대시보드 상태 반환 ───
    def get_pnl_data(self):
        """일별 수익률 데이터 반환 (Chart.js용)"""
        sorted_days = sorted(self.daily_pnl.keys())
        return {
            "labels": sorted_days,
            "values": [round(self.daily_pnl[d]) for d in sorted_days],
        }

    def get_status(self):
        cores_data = []
        for core in self.core_positions:
            cp = self.kis.get_current_price(core.ticker) if self.kis else self.current_price
            core_value = core.shares * (cp or 0)
            cores_data.append({
                "name":        core.name,
                "ticker":      core.ticker,
                "shares":      core.shares,
                "floor":       core.floor_shares,
                "price":       cp or 0,
                "value":       core_value,
                "strategy":    "장기 우상향/RSI(9)" if core.ticker != CORE_TICKER else "RSI(9) 30/70 + floor 보호"
            })

        satellites = []
        for ticker, pos in self.satellite_positions.items():
            satellites.append({
                "name":     pos.name,
                "ticker":   ticker,
                "strategy": self.satellite_strategies.get(ticker, '-'),
                "shares":   pos.shares,
                "cash":     round(pos.cash),
                "value":    round(pos.current_value),
            })

        return {
            "is_running":    self.is_running,
            "has_keys":      self.kis is not None,
            "logs":          self.logs[-30:],
            "hot_sectors":   self.hot_sectors,
            "num_satellites": self.num_satellites,
            "cores":         cores_data,
            "satellites":    satellites,
        }

class BotManager:
    """모든 사용자의 봇 인스턴스를 관리합니다."""
    def __init__(self):
        self.bots = {}  # {user_id: BotController}

    def get_bot(self, user_id, user_data=None):
        if user_id not in self.bots:
            if user_data:
                # 사용자 데이터를 기반으로 새 봇 생성
                kis_config = {
                    "app_key": user_data.get('kis_app_key'),
                    "app_secret": user_data.get('kis_app_secret'),
                    "account_no": user_data.get('kis_account_no'),
                    "is_mock": True # 기본 모의투자
                }
                tele_config = {
                    "token": user_data.get('telegram_token'),
                    "chat_id": user_data.get('telegram_chat_id')
                }
                self.bots[user_id] = BotController(user_id, kis_config, tele_config)
            else:
                return None
        return self.bots[user_id]

    def stop_all(self):
        for bot in self.bots.values():
            bot.stop()

# 글로벌 매니저 인스턴스
manager = BotManager()
